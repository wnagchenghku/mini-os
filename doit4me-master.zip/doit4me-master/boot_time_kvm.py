#!/usr/bin/env python

import os
import sys
import time
import getopt
import signal
import subprocess

from datetime import datetime


TERMINATE = False
RUNNING_SUBPROCESS = None

def signal_handler(sig, frame):

    global RUNNING_SUBPROCESS
    global TERMINATE

    #terminate subprocess
    RUNNING_SUBPROCESS.terminate()
    #wait for it to terminate
    RUNNING_SUBPROCESS.wait()

    TERMINATE = True

def main(argv):

    global RUNNING_SUBPROCESS

    minicache = False
    osv = False

    try:
        opts, args = getopt.getopt(argv, "hOM", ["help", "osv=", "minicache="])

    except getopt.GetoptError:
        usage()
        sys.exit(-1)

    for opt, arg in opts:
        if opt in ("-h", "--help"):
            usage()
            sys.exit(0)
        elif opt in ("-O", "--osv"):
            osv = True
        elif opt in ("-M", "--minicache"):
            minicache = True

    if (not (minicache or osv)):
        print "Error: please specify which boot time you want to measure\n"
        usage()
        sys.exit(-1)

    if (minicache and osv):
        print "Error: select only one option to measure\n"
        usage()
        sys.exit(-1)

    tstart = datetime.now()

    if osv:
        RUNNING_SUBPROCESS = subprocess.Popen(['python', "scripts/run.py", "-i", "usr.img"], stdin=subprocess.PIPE, stdout=subprocess.PIPE, shell=False)
    else:
        RUNNING_SUBPROCESS = subprocess.Popen(['/usr/bin/kvm-guest', "-p", "3", "-b", "virbr0", "-d", "/dev/sdb7", "-d", "/dev/sdb2"], stdout=subprocess.PIPE, shell=False)

    while(True):

        retcode = RUNNING_SUBPROCESS.poll() #returns None while subprocess is running
        line = RUNNING_SUBPROCESS.stdout.readline()

        if "Total time:" in line:
	    tend = datetime.now()
	    print tend-tstart
            break

        if(retcode is not None):
            print "\nError: subprocess terminated on its own\n"
            sys.exit(-1)

    while (not TERMINATE):
        time.sleep(1)

def usage():

    print("usage: python boot_time_osv.py [-O |-M |-h ]")
    print("options and arguments:")
    print("-O     : measure boot time for OSv (also --osv)")
    print("-M     : measure boot time for minicache (also --minicache)")
    print("-h     : print this help message and exit (also --help)")

if __name__ == "__main__":
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    main(sys.argv[1:])
