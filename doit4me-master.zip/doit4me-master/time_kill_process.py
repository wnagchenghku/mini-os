#!/usr/bin/env python

import os
import sys
import signal
import getopt
import psutil

from datetime import datetime


def signal_handler(signal, frame):
    sys.exit(0)

def pids_from_name(name):

    pids = []

    for proc in psutil.process_iter():
        p = psutil.Process(proc.pid)

        if p.name == name:
            pids.append(proc.pid)

    return pids

def usage():

    print("usage: python time_kill_process.py [-p |-s |-h]")
    print("Options and arguments:")
    print("-p     : PID of the process to kill (also --pid)")
    print("-n     : name of the process to kill (also --name)")
    print("-s     : specify the signal number to be sent. (also --signal) ; default=15 (SIGTERM)")
    print("-h     : print this help message and exit (also --help)")

def main(argv):

    signal = 15

    has_pid = False
    pid = 0

    has_name = False
    name = ""

    try:
        opts, args = getopt.getopt(argv, "hp:s:n:", ["help", "pid=", "signal=", "name="])

    except getopt.GetoptError:
        usage()
        sys.exit(-1)

    for opt, arg in opts:
        if opt in ("-h", "--help"):
            usage()
            sys.exit(0)
        elif opt in ("-p", "--pid"):
            try:
                pid = int(arg)
            except:
                print "PID must be a numeric value\n"
                usage()
                exit(-1)

            has_pid = True

        elif opt in ("-s", "--signal"):
            try:
                signal = int(arg)
            except:
                print "signal must be a numeric value\n"
                usage()
                exit(-1)
        elif opt in ("-n", "--name"):
            has_name = True
            name = arg

    if (has_pid and has_name):
        print "Specify only name or PID, not both"
        sys.exit(-1)

    if ( (not has_pid) and (not has_name) ):
        print "A PID or a name must be specified"
        sys.exit(-1)

    if (has_name):
        pids = pids_from_name(name)

        if (len(pids) > 1):
            print "Multiple processes with same name found. Please specify PID instead"
            sys.exit(0)

        if (len(pids) == 0):
            print "No process with that name found"
            sys.exit(0)

        pid = pids.pop()

    tstart = datetime.now()

    try:
        os.kill(pid, signal)
    except OSError:
        print 'Could not kill process. Is the PID valid?'
        sys.exit(0)

    exists = True

    while exists:
        try:
            os.kill(pid, 0)
        except OSError: # happens when the process does not exist anymore
            exists = False
            tend = datetime.now()
            print  tend-tstart

if __name__ == "__main__":
    signal.signal(signal.SIGINT, signal_handler)
    main(sys.argv[1:])
