/* Placeholder for ARM-specific runtime include/declarations */
